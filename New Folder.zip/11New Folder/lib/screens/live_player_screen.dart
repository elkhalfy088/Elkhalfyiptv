import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:intl/intl.dart';
import '../models/channel.dart';
import '../utils/constants.dart';

class LivePlayerScreen extends StatefulWidget {
  final Channel channel;
  final List<Channel> channels;
  final int currentIndex;

  const LivePlayerScreen({
    super.key,
    required this.channel,
    required this.channels,
    required this.currentIndex,
  });

  @override
  State<LivePlayerScreen> createState() => _LivePlayerScreenState();
}

class _LivePlayerScreenState extends State<LivePlayerScreen> {
  VideoPlayerController? _controller;
  bool _hasError = false;
  late int _currentIndex;
  bool _showChannelList = true;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.currentIndex;
    WakelockPlus.enable();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    _initPlayer(widget.channels[_currentIndex].url);
  }

  Future<void> _initPlayer(String url) async {
    setState(() { _hasError = false; });
    await _controller?.dispose();
    _controller = VideoPlayerController.networkUrl(Uri.parse(url));
    try {
      await _controller!.initialize();
      await _controller!.play();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() { _hasError = true; });
    }
  }

  void _switchChannel(int index) {
    if (index < 0 || index >= widget.channels.length) return;
    setState(() => _currentIndex = index);
    _initPlayer(widget.channels[index].url);
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ch = widget.channels[_currentIndex];
    final now = DateTime.now();
    final timeStr = DateFormat('hh:mm a').format(now);
    final dateStr = DateFormat('MMM. d y').format(now);

    return Scaffold(
      backgroundColor: Colors.black,
      body: Row(
        children: [
          // Channel list sidebar
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: _showChannelList ? 300 : 0,
            child: _showChannelList ? _buildSidebar(ch) : const SizedBox.shrink(),
          ),
          // Player
          Expanded(
            child: Stack(
              children: [
                // Video
                Container(
                  color: Colors.black,
                  child: Center(
                    child: _hasError
                        ? _buildError()
                        : _controller != null && _controller!.value.isInitialized
                            ? AspectRatio(
                                aspectRatio: _controller!.value.aspectRatio,
                                child: VideoPlayer(_controller!),
                              )
                            : _buildLoading(),
                  ),
                ),
                // Top bar
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.black.withValues(alpha: 0.7), Colors.transparent],
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Text(
                          '$timeStr | $dateStr',
                          style: const TextStyle(color: Colors.white70, fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                ),
                // Bottom fullscreen button only
                Positioned(
                  bottom: 10,
                  right: 10,
                  child: IconButton(
                    icon: const Icon(Icons.fullscreen_rounded, color: Colors.white70, size: 28),
                    onPressed: () => setState(() => _showChannelList = !_showChannelList),
                  ),
                ),
                // Right info panel
                Positioned(
                  top: 60,
                  right: 16,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.redAccent,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text(
                          '● Live TV',
                          style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        ch.name,
                        style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'No Information',
                        style: TextStyle(color: Colors.white54, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSidebar(Channel currentCh) {
    final group = currentCh.group ?? '';
    return Container(
      color: const Color(0xFF1A1A2E),
      child: Column(
        children: [
          // Group navigation
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(0),
                bottomRight: Radius.circular(0),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Icon(Icons.chevron_left_rounded, color: Colors.white),
                Expanded(
                  child: Text(
                    group,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: Colors.white),
              ],
            ),
          ),
          // Channel list
          Expanded(
            child: ListView.separated(
              itemCount: widget.channels.length,
              separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
              itemBuilder: (_, i) {
                final c = widget.channels[i];
                final isSelected = i == _currentIndex;
                return GestureDetector(
                  onTap: () => _switchChannel(i),
                  child: Container(
                    color: isSelected ? AppColors.primary.withValues(alpha: 0.2) : Colors.transparent,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    child: Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: AppColors.card,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: c.logo != null && c.logo!.isNotEmpty
                                ? Image.network(c.logo!, fit: BoxFit.contain, errorBuilder: (_, __, ___) => _logoFallback())
                                : _logoFallback(),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                c.name,
                                style: TextStyle(
                                  color: isSelected ? AppColors.primary : Colors.white,
                                  fontSize: 13,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const Text(
                                'No Information',
                                style: TextStyle(color: AppColors.textSecondary, fontSize: 10),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoading() => const Center(
    child: SizedBox(
      width: 40,
      height: 40,
      child: CircularProgressIndicator(
        color: AppColors.primary,
        strokeWidth: 3,
      ),
    ),
  );

  Widget _buildError() => Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 48),
      const SizedBox(height: 12),
      const Text('تعذر تشغيل القناة', style: TextStyle(color: Colors.white, fontSize: 14)),
      const SizedBox(height: 12),
      ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
        onPressed: () => _initPlayer(widget.channels[_currentIndex].url),
        child: const Text('إعادة المحاولة'),
      ),
    ],
  );

  Widget _logoFallback() => const Center(
    child: Icon(Icons.tv_rounded, color: AppColors.textSecondary, size: 18),
  );
}
