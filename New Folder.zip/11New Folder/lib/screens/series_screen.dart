import 'package:flutter/material.dart';
import '../models/category.dart';
import '../models/channel.dart';
import '../utils/constants.dart';
import '../widgets/channel_card.dart';
import 'vod_player_screen.dart';

class SeriesScreen extends StatefulWidget {
  final List<Category> allCategories;
  const SeriesScreen({super.key, required this.allCategories});

  @override
  State<SeriesScreen> createState() => _SeriesScreenState();
}

class _SeriesScreenState extends State<SeriesScreen> {
  int _selectedCat = 0;
  String _search = '';
  final _searchCtrl = TextEditingController();

  List<Category> get _cats => widget.allCategories.isEmpty ? [] : widget.allCategories;

  List<Channel> get _channels {
    if (_cats.isEmpty) return [];
    final cat = _cats[_selectedCat];
    final list = cat.name == 'All'
        ? widget.allCategories.expand((c) => c.channels).toSet().toList()
        : cat.channels;
    if (_search.isEmpty) return list;
    return list
        .where((c) => c.name.toLowerCase().contains(_search.toLowerCase()))
        .toList();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.allCategories.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.video_library_rounded, color: AppColors.textSecondary, size: 64),
            SizedBox(height: 16),
            Text('لا توجد مسلسلات متاحة', style: TextStyle(color: AppColors.textSecondary, fontSize: 16)),
          ],
        ),
      );
    }

    return Row(
      children: [
        Container(
          width: 220,
          color: AppColors.surface,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _search = v),
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Search Categories',
                    hintStyle: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                    prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textSecondary, size: 18),
                    filled: true,
                    fillColor: AppColors.card,
                    contentPadding: const EdgeInsets.symmetric(vertical: 8),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: _cats.length,
                  itemBuilder: (_, i) {
                    final cat = _cats[i];
                    final selected = i == _selectedCat;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedCat = i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: selected ? AppColors.primary : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                cat.name,
                                style: TextStyle(
                                  color: selected ? Colors.white : AppColors.textSecondary,
                                  fontSize: 13,
                                  fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Text(
                              '${cat.count}',
                              style: TextStyle(
                                color: selected ? Colors.white70 : AppColors.textSecondary,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Text(
                  _cats.isNotEmpty ? _cats[_selectedCat].name : 'All',
                  style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.all(10),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 5,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                    childAspectRatio: 0.65,
                  ),
                  itemCount: _channels.length,
                  itemBuilder: (_, i) {
                    final ch = _channels[i];
                    return ChannelCard(
                      channel: ch,
                      isLive: false,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => VodPlayerScreen(channel: ch),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
