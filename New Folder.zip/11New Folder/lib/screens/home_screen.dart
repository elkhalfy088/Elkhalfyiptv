import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/m3u_service.dart';
import '../models/category.dart';
import '../utils/constants.dart';
import 'live_tv_screen.dart';
import 'movies_screen.dart';
import 'series_screen.dart';
import 'activation_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  List<Category> _allCategories = [];
  bool _loading = true;
  String _m3uUrl = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _m3uUrl = prefs.getString('m3u_url') ?? '';
    if (_m3uUrl.isEmpty) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    final cats = await M3uService.fetchAndParse(_m3uUrl);
    if (mounted) setState(() { _allCategories = cats; _loading = false; });
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const ActivationScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final tabs = ['Live TV', 'Movies', 'Series'];
    final icons = [
      Icons.live_tv_rounded,
      Icons.movie_rounded,
      Icons.video_library_rounded,
    ];

    if (_loading) {
      return Scaffold(
        backgroundColor: AppColors.bg,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                width: 48,
                height: 48,
                child: CircularProgressIndicator(
                  color: AppColors.primary,
                  strokeWidth: 3,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'جاري تحميل القنوات...',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 16),
              ),
            ],
          ),
        ),
      );
    }

    Widget body;
    switch (_tab) {
      case 0:
        body = LiveTvScreen(allCategories: _allCategories);
        break;
      case 1:
        body = MoviesScreen(allCategories: _allCategories);
        break;
      case 2:
        body = SeriesScreen(allCategories: _allCategories);
        break;
      default:
        body = LiveTvScreen(allCategories: _allCategories);
    }

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.all(8),
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [AppColors.primary, AppColors.primaryDark],
              ),
            ),
            child: const Center(
              child: Text(
                'K',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ),
          ),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (int i = 0; i < tabs.length; i++)
              GestureDetector(
                onTap: () => setState(() => _tab = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: _tab == i
                        ? AppColors.primary
                        : AppColors.primary.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: _tab != i
                        ? Border.all(
                            color: AppColors.primary.withValues(alpha: 0.3),
                            width: 1)
                        : null,
                  ),
                  child: Row(
                    children: [
                      Icon(icons[i],
                          size: 15,
                          color: _tab == i
                              ? Colors.white
                              : AppColors.textSecondary),
                      const SizedBox(width: 5),
                      Text(
                        tabs[i],
                        style: TextStyle(
                          color:
                              _tab == i ? Colors.white : AppColors.textSecondary,
                          fontSize: 13,
                          fontWeight: _tab == i
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded, color: Colors.white),
            onPressed: () {},
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded, color: Colors.white),
            color: AppColors.surface,
            onSelected: (v) {
              if (v == 'logout') _logout();
            },
            itemBuilder: (_) => [
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout_rounded, color: Colors.redAccent, size: 18),
                    SizedBox(width: 8),
                    Text('تسجيل الخروج',
                        style: TextStyle(color: Colors.white)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: body,
      ),
    );
  }
}
