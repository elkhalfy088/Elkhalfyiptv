import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FirebaseService {
  static final _db = FirebaseDatabase.instance.ref();

  static Future<Map<String, dynamic>> validateCode(String code) async {
    try {
      final snap = await _db.child('codes/$code').get();
      if (!snap.exists) {
        return {'success': false, 'message': 'كود التفعيل غير صحيح'};
      }
      final data = Map<dynamic, dynamic>.from(snap.value as Map);
      final expiry = DateTime.tryParse(data['expiryDate']?.toString() ?? '');
      if (expiry == null || expiry.isBefore(DateTime.now())) {
        return {'success': false, 'message': 'كود التفعيل منتهي الصلاحية'};
      }
      final m3uUrl = data['m3uUrl']?.toString() ?? '';
      final getCodeUrl = data['getCodeUrl']?.toString() ?? '';
      if (m3uUrl.isEmpty) {
        return {'success': false, 'message': 'لا يوجد رابط اشتراك مرتبط بهذا الكود'};
      }
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('activation_code', code);
      await prefs.setString('m3u_url', m3uUrl);
      await prefs.setString('expiry_date', expiry.toIso8601String());
      await prefs.setString('get_code_url', getCodeUrl);
      return {'success': true, 'm3uUrl': m3uUrl, 'getCodeUrl': getCodeUrl};
    } catch (e) {
      return {'success': false, 'message': 'خطأ في الاتصال بالخادم'};
    }
  }

  static Future<String> getGetCodeUrl() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final code = prefs.getString('activation_code') ?? '';
      if (code.isNotEmpty) {
        final snap = await _db.child('codes/$code/getCodeUrl').get();
        if (snap.exists) return snap.value.toString();
      }
      final snap = await _db.child('settings/getCodeUrl').get();
      if (snap.exists) return snap.value.toString();
    } catch (_) {}
    return '';
  }
}
