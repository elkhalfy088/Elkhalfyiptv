import 'package:http/http.dart' as http;
import '../models/channel.dart';
import '../models/category.dart';

class M3uService {
  static Future<List<Category>> fetchAndParse(String url) async {
    try {
      final response = await http.get(Uri.parse(url)).timeout(
        const Duration(seconds: 30),
      );
      if (response.statusCode != 200) return [];
      return _parseM3u(response.body);
    } catch (_) {
      return [];
    }
  }

  static List<Category> _parseM3u(String content) {
    final lines = content.split('\n');
    final Map<String, List<Channel>> groups = {};
    Channel? pending;

    for (var line in lines) {
      line = line.trim();
      if (line.startsWith('#EXTINF')) {
        final name = _extractAttr(line, 'tvg-name') ??
            line.split(',').last.trim();
        final logo = _extractAttr(line, 'tvg-logo');
        final group = _extractAttr(line, 'group-title') ?? 'General';
        final id = _extractAttr(line, 'tvg-id');
        pending = Channel(name: name, url: '', logo: logo, group: group, tvgId: id);
      } else if (line.startsWith('http') && pending != null) {
        final ch = Channel(
          name: pending.name,
          url: line,
          logo: pending.logo,
          group: pending.group,
          tvgId: pending.tvgId,
        );
        groups.putIfAbsent(ch.group ?? 'General', () => []).add(ch);
        pending = null;
      }
    }

    final all = groups.values.expand((e) => e).toList();
    final cats = <Category>[
      Category(name: 'All', channels: all),
      Category(name: 'Favorites', channels: []),
    ];
    groups.forEach((key, value) => cats.add(Category(name: key, channels: value)));
    return cats;
  }

  static String? _extractAttr(String line, String attr) {
    final re = RegExp('$attr="([^"]*)"');
    return re.firstMatch(line)?.group(1);
  }

  static List<Category> filterByType(List<Category> cats, String type) {
    // type: live, movie, series
    final keywords = {
      'live': ['live', 'tv', 'channel', 'القنوات', 'تلفزيون', 'بث'],
      'movie': ['movie', 'vod', 'film', 'أفلام', 'فيلم', 'سينما'],
      'series': ['series', 'show', 'مسلسل', 'مسلسلات'],
    };
    final kws = keywords[type] ?? [];
    if (kws.isEmpty) return cats;
    return cats.map((cat) {
      if (cat.name == 'All' || cat.name == 'Favorites') return cat;
      final lower = cat.name.toLowerCase();
      final matches = kws.any((kw) => lower.contains(kw.toLowerCase()));
      if (!matches) return null;
      return cat;
    }).whereType<Category>().toList();
  }
}
