import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF0F0F23);
  static const surface = Color(0xFF1A1A2E);
  static const card = Color(0xFF16213E);
  static const primary = Color(0xFF8B5CF6);
  static const primaryDark = Color(0xFF5B21B6);
  static const accent = Color(0xFF7C3AED);
  static const text = Colors.white;
  static const textSecondary = Color(0xFFAAAAAA);
  static const divider = Color(0xFF2A2A4A);
}

class AppGradients {
  static const primary = LinearGradient(
    colors: [AppColors.primary, AppColors.primaryDark],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const bg = LinearGradient(
    colors: [Color(0xFF0F0F23), Color(0xFF1A1A2E)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}
