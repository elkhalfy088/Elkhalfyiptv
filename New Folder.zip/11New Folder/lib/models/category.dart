import 'channel.dart';

class Category {
  final String name;
  final List<Channel> channels;

  Category({required this.name, required this.channels});

  int get count => channels.length;
}
