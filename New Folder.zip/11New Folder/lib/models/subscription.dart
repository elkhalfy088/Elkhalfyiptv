class Subscription {
  final String code;
  final String m3uUrl;
  final DateTime expiryDate;
  final String getCodeUrl;

  Subscription({
    required this.code,
    required this.m3uUrl,
    required this.expiryDate,
    required this.getCodeUrl,
  });

  bool get isValid => expiryDate.isAfter(DateTime.now());

  factory Subscription.fromMap(Map<dynamic, dynamic> map) {
    return Subscription(
      code: map['code']?.toString() ?? '',
      m3uUrl: map['m3uUrl']?.toString() ?? '',
      expiryDate: DateTime.tryParse(map['expiryDate']?.toString() ?? '') ??
          DateTime.now().subtract(const Duration(days: 1)),
      getCodeUrl: map['getCodeUrl']?.toString() ?? '',
    );
  }
}
