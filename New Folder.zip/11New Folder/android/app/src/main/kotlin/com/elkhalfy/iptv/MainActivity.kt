package com.elkhalfy.iptv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
