# ELKHALFY IPTV - Flutter Project

## متطلبات التشغيل
- Flutter SDK 3.19+
- Android Studio / VS Code
- حساب Firebase (مُعدَّ مسبقاً)

## خطوات التثبيت

### 1. استخراج المشروع
```bash
unzip elkhalfy_flutter.zip -d elkhalfy_iptv
cd elkhalfy_iptv
```

### 2. تثبيت الحزم
```bash
flutter pub get
```

### 3. تشغيل التطبيق
```bash
flutter run
```

### 4. بناء APK
```bash
flutter build apk --release
```
الملف: `build/app/outputs/flutter-apk/app-release.apk`

## هيكل المشروع
```
lib/
├── main.dart              # نقطة الدخول + شاشة السبلاش
├── firebase_options.dart  # إعدادات Firebase
├── models/                # نماذج البيانات
│   ├── channel.dart
│   ├── category.dart
│   └── subscription.dart
├── screens/               # الشاشات
│   ├── activation_screen.dart   # شاشة التفعيل
│   ├── home_screen.dart         # الشاشة الرئيسية + تابس
│   ├── live_tv_screen.dart      # قنوات مباشرة
│   ├── movies_screen.dart       # أفلام
│   ├── series_screen.dart       # مسلسلات
│   ├── live_player_screen.dart  # مشغل القنوات (بدون أزرار)
│   └── vod_player_screen.dart   # مشغل الأفلام (مع شريط)
├── services/
│   ├── firebase_service.dart    # التحقق من الأكواد
│   └── m3u_service.dart         # تحميل وتحليل M3U
├── utils/
│   └── constants.dart           # الألوان والثيمات
└── widgets/
    └── channel_card.dart        # بطاقة القناة

android/
└── app/
    └── google-services.json     # إعدادات Firebase
```

## ميزات التطبيق
- ✅ شاشة تفعيل بكود (Firebase Realtime Database)
- ✅ Live TV مع قائمة تصنيفات
- ✅ أفلام ومسلسلات
- ✅ مشغل قنوات مباشرة (بدون أزرار، مع قائمة القنوات)
- ✅ مشغل VOD (مع شريط تحريك كامل)
- ✅ تصميم داكن احترافي بتدرجات بنفسجية
- ✅ "احصل على كود التفعيل" يفتح رابط خارجي

## إعدادات Firebase (مُضمَّنة)
Firebase معدّ مسبقاً. الأكواد تُدار من لوحة التحكم HTML.
