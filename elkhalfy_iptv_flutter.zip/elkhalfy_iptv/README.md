# ELKHALFY IPTV — Flutter App

## مشروع Flutter احترافي جاهز للبناء عبر Codemagic

---

## هيكل المشروع

```
elkhalfy_iptv/
├── lib/
│   ├── main.dart                     # نقطة الدخول
│   ├── firebase_options.dart         # إعدادات Firebase
│   ├── models/                       # نماذج البيانات
│   │   ├── server_model.dart
│   │   ├── channel_model.dart
│   │   ├── movie_model.dart
│   │   ├── series_model.dart
│   │   └── category_model.dart
│   ├── services/
│   │   ├── firebase_service.dart     # Firebase Realtime DB
│   │   └── xtream_service.dart       # Xtream Codes API
│   ├── providers/
│   │   ├── app_provider.dart         # State Management
│   │   └── player_provider.dart
│   ├── screens/
│   │   ├── splash_screen.dart
│   │   ├── login_screen.dart
│   │   ├── home_screen.dart
│   │   ├── live_tv_screen.dart
│   │   ├── movies_screen.dart
│   │   ├── series_screen.dart
│   │   ├── live_player_screen.dart
│   │   ├── vod_player_screen.dart
│   │   └── series_detail_screen.dart
│   ├── widgets/
│   │   ├── category_sidebar.dart
│   │   ├── channel_card.dart
│   │   ├── media_card.dart
│   │   └── network_image_cached.dart
│   └── utils/
│       └── app_theme.dart
├── android/
│   ├── app/
│   │   ├── google-services.json      # Firebase Android config
│   │   ├── build.gradle
│   │   └── src/main/
│   └── build.gradle
├── ios/
│   └── Runner/
│       ├── GoogleService-Info.plist  # Firebase iOS config
│       └── Info.plist
├── pubspec.yaml
└── codemagic.yaml                    # CI/CD config
```

---

## إعداد Firebase (مهم)

### هيكل قاعدة البيانات في Firebase Realtime Database:

```json
{
  "codes": {
    "CODE123": {
      "isActive": true,
      "serverUrl": "http://yourserver.com:8080",
      "username": "user123",
      "password": "pass123",
      "serverName": "ELKHALFY Premium",
      "expiry": "2026-12-31",
      "socialLinks": {
        "Telegram": "https://t.me/elkhalfy_iptv",
        "WhatsApp": "https://wa.me/213XXXXXXXXX",
        "YouTube": "https://youtube.com/@elkhalfy",
        "Facebook": "https://facebook.com/elkhalfy",
        "Website": "https://elkhalfy.com"
      }
    }
  },
  "settings": {
    "appVersion": "1.0.0",
    "maintenance": false,
    "announcement": ""
  }
}
```

---

## البناء عبر Codemagic

1. ارفع المشروع على GitHub
2. اربطه بـ Codemagic
3. أضف متغيرات البيئة:
   - `CM_KEYSTORE` - ملف keystore لـ Android
   - `CM_KEYSTORE_PASSWORD`
   - `CM_KEY_ALIAS`
   - `CM_KEY_PASSWORD`
4. ابدأ البناء

---

## الميزات

- ✅ شاشة تفعيل بكود مع Firebase
- ✅ دعم Xtream Codes API الكامل
- ✅ قنوات مباشرة بدون أزرار تحكم
- ✅ مشغل أفلام/مسلسلات بشريط تحكم كامل
- ✅ تحميل تدريجي (الأفلام تظهر فور تحميلها)
- ✅ بحث في الفئات والمحتوى
- ✅ المفضلة (قنوات، أفلام، مسلسلات)
- ✅ قائمة روابط التواصل الاجتماعي
- ✅ دعم الوضع الأفقي والعمودي
- ✅ تصميم داكن احترافي بألوان بنفسجية
