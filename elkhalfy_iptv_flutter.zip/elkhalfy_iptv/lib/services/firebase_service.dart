import 'package:firebase_database/firebase_database.dart';
import '../models/server_model.dart';

class FirebaseService {
  static final FirebaseDatabase _db = FirebaseDatabase.instance;

  /// Validate activation code and retrieve server info
  static Future<ServerModel?> validateCode(String code) async {
    try {
      final ref = _db.ref('codes/${code.trim().toUpperCase()}');
      final snapshot = await ref.get();
      if (!snapshot.exists) return null;
      final data = snapshot.value as Map<dynamic, dynamic>;
      if (data['isActive'] != true) return null;
      return ServerModel.fromMap(code.trim().toUpperCase(), data);
    } catch (e) {
      return null;
    }
  }

  /// Get app settings (social links, announcements, etc.)
  static Future<Map<String, dynamic>> getAppSettings() async {
    try {
      final ref = _db.ref('settings');
      final snapshot = await ref.get();
      if (!snapshot.exists) return {};
      return Map<String, dynamic>.from(snapshot.value as Map);
    } catch (e) {
      return {};
    }
  }

  /// Get social links for a specific server code
  static Future<Map<String, String>> getSocialLinks(String code) async {
    try {
      final ref = _db.ref('codes/${code.toUpperCase()}/socialLinks');
      final snapshot = await ref.get();
      if (!snapshot.exists) return {};
      final raw = snapshot.value as Map<dynamic, dynamic>;
      return raw.map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (e) {
      return {};
    }
  }
}
