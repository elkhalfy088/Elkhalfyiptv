import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/channel_model.dart';
import '../models/movie_model.dart';
import '../models/series_model.dart';
import '../models/category_model.dart';

class XtreamService {
  final String baseUrl;
  final String username;
  final String password;
  final Duration _timeout = const Duration(seconds: 15);

  XtreamService({
    required this.baseUrl,
    required this.username,
    required this.password,
  });

  String get _apiUrl => '$baseUrl/player_api.php';

  Map<String, String> get _baseParams => {
    'username': username,
    'password': password,
  };

  Future<Map<String, dynamic>?> _get(Map<String, String> params) async {
    try {
      final uri = Uri.parse(_apiUrl).replace(
        queryParameters: {..._baseParams, ...params},
      );
      final resp = await http.get(uri).timeout(_timeout);
      if (resp.statusCode == 200) {
        return json.decode(resp.body) as Map<String, dynamic>;
      }
    } catch (_) {}
    return null;
  }

  Future<List<dynamic>?> _getList(Map<String, String> params) async {
    try {
      final uri = Uri.parse(_apiUrl).replace(
        queryParameters: {..._baseParams, ...params},
      );
      final resp = await http.get(uri).timeout(_timeout);
      if (resp.statusCode == 200) {
        final body = json.decode(resp.body);
        if (body is List) return body;
      }
    } catch (_) {}
    return null;
  }

  // ─── Authentication ──────────────────────────────────────────────
  Future<bool> authenticate() async {
    final data = await _get({'action': 'get_server_info'});
    return data != null;
  }

  // ─── Live TV ─────────────────────────────────────────────────────
  Future<List<CategoryModel>> getLiveCategories() async {
    final data = await _getList({'action': 'get_live_categories'});
    if (data == null) return [];
    return data
        .map((e) => CategoryModel.fromMap(e as Map<dynamic, dynamic>))
        .toList();
  }

  Future<List<ChannelModel>> getLiveStreams({String? categoryId}) async {
    final params = <String, String>{'action': 'get_live_streams'};
    if (categoryId != null && categoryId.isNotEmpty) {
      params['category_id'] = categoryId;
    }
    final data = await _getList(params);
    if (data == null) return [];
    return data
        .map((e) => ChannelModel.fromMap(e as Map<dynamic, dynamic>))
        .toList();
  }

  // ─── Movies (VOD) ─────────────────────────────────────────────────
  Future<List<CategoryModel>> getVodCategories() async {
    final data = await _getList({'action': 'get_vod_categories'});
    if (data == null) return [];
    return data
        .map((e) => CategoryModel.fromMap(e as Map<dynamic, dynamic>))
        .toList();
  }

  Future<List<MovieModel>> getVodStreams({String? categoryId}) async {
    final params = <String, String>{'action': 'get_vod_streams'};
    if (categoryId != null && categoryId.isNotEmpty) {
      params['category_id'] = categoryId;
    }
    final data = await _getList(params);
    if (data == null) return [];
    return data
        .map((e) => MovieModel.fromMap(e as Map<dynamic, dynamic>))
        .toList();
  }

  // ─── Series ──────────────────────────────────────────────────────
  Future<List<CategoryModel>> getSeriesCategories() async {
    final data = await _getList({'action': 'get_series_categories'});
    if (data == null) return [];
    return data
        .map((e) => CategoryModel.fromMap(e as Map<dynamic, dynamic>))
        .toList();
  }

  Future<List<SeriesModel>> getSeries({String? categoryId}) async {
    final params = <String, String>{'action': 'get_series'};
    if (categoryId != null && categoryId.isNotEmpty) {
      params['category_id'] = categoryId;
    }
    final data = await _getList(params);
    if (data == null) return [];
    return data
        .map((e) => SeriesModel.fromMap(e as Map<dynamic, dynamic>))
        .toList();
  }

  Future<Map<String, List<EpisodeModel>>> getSeriesInfo(String seriesId) async {
    final data = await _get({'action': 'get_series_info', 'series_id': seriesId});
    if (data == null) return {};
    final episodes = data['episodes'];
    if (episodes == null) return {};
    final result = <String, List<EpisodeModel>>{};
    (episodes as Map<dynamic, dynamic>).forEach((season, epList) {
      result[season.toString()] = (epList as List)
          .map((e) => EpisodeModel.fromMap(e as Map<dynamic, dynamic>))
          .toList()
        ..sort((a, b) => a.episodeNum.compareTo(b.episodeNum));
    });
    return result;
  }

  // ─── Stream URLs ──────────────────────────────────────────────────
  String getLiveUrl(String streamId) =>
      '$baseUrl/live/$username/$password/$streamId.ts';

  String getMovieUrl(String streamId, [String ext = 'mp4']) =>
      '$baseUrl/movie/$username/$password/$streamId.$ext';

  String getEpisodeUrl(String episodeId, [String ext = 'mp4']) =>
      '$baseUrl/series/$username/$password/$episodeId.$ext';
}
