import 'package:flutter/material.dart';
import '../utils/app_theme.dart';
import 'network_image_cached.dart';

class MediaCard extends StatelessWidget {
  final String title;
  final String? imageUrl;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onFav;

  const MediaCard({
    super.key,
    required this.title,
    this.imageUrl,
    required this.isFavorite,
    required this.onTap,
    required this.onFav,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.cardBorder, width: 0.5),
        ),
        child: Stack(
          children: [
            // Poster
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: imageUrl != null && imageUrl!.isNotEmpty
                    ? CachedImage(url: imageUrl!, fit: BoxFit.cover)
                    : Container(
                        color: AppTheme.bgSidebar,
                        child: const Center(
                          child: Icon(Icons.movie_rounded, color: AppTheme.textMuted, size: 36),
                        ),
                      ),
              ),
            ),
            // Gradient overlay at bottom
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black87],
                  ),
                  borderRadius: BorderRadius.vertical(bottom: Radius.circular(10)),
                ),
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                    height: 1.3,
                  ),
                ),
              ),
            ),
            // Favorite button
            Positioned(
              top: 4,
              right: 4,
              child: GestureDetector(
                onTap: onFav,
                child: Container(
                  width: 24,
                  height: 24,
                  decoration: const BoxDecoration(
                    color: Colors.black54,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: isFavorite ? Colors.pinkAccent : Colors.white70,
                    size: 13,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
