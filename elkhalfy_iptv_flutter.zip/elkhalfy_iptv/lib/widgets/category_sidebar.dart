import 'package:flutter/material.dart';
import '../models/category_model.dart';
import '../utils/app_theme.dart';

class CategorySidebar extends StatelessWidget {
  final List<CategoryModel> categories;
  final String selectedId;
  final TextEditingController searchController;
  final String searchHint;
  final void Function(String) onSearch;
  final void Function(String) onSelect;

  const CategorySidebar({
    super.key,
    required this.categories,
    required this.selectedId,
    required this.searchController,
    required this.searchHint,
    required this.onSearch,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppTheme.bgSidebar,
      child: Column(
        children: [
          // Search
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: TextField(
              controller: searchController,
              onChanged: onSearch,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: searchHint,
                hintStyle: const TextStyle(color: AppTheme.textMuted, fontSize: 13),
                prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted, size: 18),
                filled: true,
                fillColor: AppTheme.bgCard,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: AppTheme.divider),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: AppTheme.divider),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: AppTheme.primary, width: 1.2),
                ),
              ),
            ),
          ),
          // Category list
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.only(bottom: 8),
              itemCount: categories.length,
              itemExtent: 46,
              itemBuilder: (_, i) {
                final cat = categories[i];
                final isSelected = cat.categoryId == selectedId;
                final isFav = cat.categoryId == 'fav';

                return GestureDetector(
                  onTap: () => onSelect(cat.categoryId),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                    decoration: BoxDecoration(
                      color: isSelected ? AppTheme.primary : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: isSelected
                          ? [BoxShadow(
                              color: AppTheme.primary.withOpacity(0.3),
                              blurRadius: 8,
                            )]
                          : null,
                    ),
                    child: Row(
                      children: [
                        if (isFav)
                          Icon(
                            Icons.favorite,
                            size: 13,
                            color: isSelected ? Colors.white : Colors.pinkAccent,
                          )
                        else
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isSelected ? Colors.white : AppTheme.textMuted,
                            ),
                          ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            cat.categoryName,
                            style: TextStyle(
                              color: isSelected ? Colors.white : AppTheme.textSecondary,
                              fontSize: 13,
                              fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (cat.count > 0)
                          Text(
                            cat.count.toString(),
                            style: TextStyle(
                              color: isSelected ? Colors.white70 : AppTheme.textMuted,
                              fontSize: 11,
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
