import 'package:flutter/material.dart';
import '../models/channel_model.dart';
import '../utils/app_theme.dart';
import 'network_image_cached.dart';

class ChannelCard extends StatelessWidget {
  final ChannelModel channel;
  final VoidCallback onTap;
  final VoidCallback onFav;

  const ChannelCard({
    super.key,
    required this.channel,
    required this.onTap,
    required this.onFav,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.cardBorder, width: 0.5),
        ),
        child: Stack(
          children: [
            // Image/Icon
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: channel.streamIcon != null && channel.streamIcon!.isNotEmpty
                    ? Padding(
                        padding: const EdgeInsets.all(8),
                        child: CachedImage(url: channel.streamIcon!, fit: BoxFit.contain),
                      )
                    : const Center(
                        child: Icon(Icons.live_tv_rounded, color: AppTheme.textMuted, size: 32),
                      ),
              ),
            ),
            // Name at bottom
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black87],
                  ),
                  borderRadius: BorderRadius.vertical(bottom: Radius.circular(10)),
                ),
                child: Text(
                  channel.name,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            // Favorite
            Positioned(
              top: 4,
              right: 4,
              child: GestureDetector(
                onTap: onFav,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    channel.isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: channel.isFavorite ? Colors.pinkAccent : Colors.white70,
                    size: 12,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
