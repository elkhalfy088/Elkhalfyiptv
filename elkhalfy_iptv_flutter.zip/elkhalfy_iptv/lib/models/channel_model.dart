class ChannelModel {
  final String streamId;
  final String name;
  final String? streamIcon;
  final String categoryId;
  final int num;
  final String? epgChannelId;
  final bool isFavorite;

  ChannelModel({
    required this.streamId,
    required this.name,
    this.streamIcon,
    required this.categoryId,
    required this.num,
    this.epgChannelId,
    this.isFavorite = false,
  });

  factory ChannelModel.fromMap(Map<dynamic, dynamic> map) {
    return ChannelModel(
      streamId: map['stream_id']?.toString() ?? '',
      name: map['name']?.toString() ?? '',
      streamIcon: map['stream_icon']?.toString(),
      categoryId: map['category_id']?.toString() ?? '',
      num: int.tryParse(map['num']?.toString() ?? '0') ?? 0,
      epgChannelId: map['epg_channel_id']?.toString(),
    );
  }

  String getStreamUrl(String baseUrl, String username, String password) {
    return '$baseUrl/live/$username/$password/$streamId.ts';
  }

  ChannelModel copyWith({bool? isFavorite}) {
    return ChannelModel(
      streamId: streamId,
      name: name,
      streamIcon: streamIcon,
      categoryId: categoryId,
      num: num,
      epgChannelId: epgChannelId,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }
}
