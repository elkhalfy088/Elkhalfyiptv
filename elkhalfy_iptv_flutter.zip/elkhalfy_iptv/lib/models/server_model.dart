class ServerModel {
  final String code;
  final String serverUrl;
  final String username;
  final String password;
  final String serverName;
  final bool isActive;
  final DateTime? expiry;
  final Map<String, String> socialLinks;
  final String? whatsapp;
  final String? telegram;
  final String? website;

  ServerModel({
    required this.code,
    required this.serverUrl,
    required this.username,
    required this.password,
    required this.serverName,
    this.isActive = true,
    this.expiry,
    this.socialLinks = const {},
    this.whatsapp,
    this.telegram,
    this.website,
  });

  factory ServerModel.fromMap(String code, Map<dynamic, dynamic> map) {
    final socialMap = <String, String>{};
    if (map['socialLinks'] != null) {
      (map['socialLinks'] as Map<dynamic, dynamic>).forEach((k, v) {
        socialMap[k.toString()] = v.toString();
      });
    }
    return ServerModel(
      code: code,
      serverUrl: map['serverUrl']?.toString() ?? '',
      username: map['username']?.toString() ?? '',
      password: map['password']?.toString() ?? '',
      serverName: map['serverName']?.toString() ?? 'ELKHALFY IPTV',
      isActive: map['isActive'] == true,
      expiry: map['expiry'] != null
          ? DateTime.tryParse(map['expiry'].toString())
          : null,
      socialLinks: socialMap,
      whatsapp: map['whatsapp']?.toString(),
      telegram: map['telegram']?.toString(),
      website: map['website']?.toString(),
    );
  }

  String get baseUrl {
    String url = serverUrl.trim();
    if (!url.startsWith('http')) url = 'http://$url';
    if (url.endsWith('/')) url = url.substring(0, url.length - 1);
    return url;
  }

  String get apiUrl => '$baseUrl/player_api.php';

  bool get isExpired {
    if (expiry == null) return false;
    return DateTime.now().isAfter(expiry!);
  }
}
