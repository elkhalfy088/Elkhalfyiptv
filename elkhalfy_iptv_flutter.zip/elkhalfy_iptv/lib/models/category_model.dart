class CategoryModel {
  final String categoryId;
  final String categoryName;
  final int parentId;
  int count;

  CategoryModel({
    required this.categoryId,
    required this.categoryName,
    this.parentId = 0,
    this.count = 0,
  });

  factory CategoryModel.fromMap(Map<dynamic, dynamic> map) {
    return CategoryModel(
      categoryId: map['category_id']?.toString() ?? '',
      categoryName: map['category_name']?.toString() ?? '',
      parentId: int.tryParse(map['parent_id']?.toString() ?? '0') ?? 0,
    );
  }
}
