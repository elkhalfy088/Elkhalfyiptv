class SeriesModel {
  final String seriesId;
  final String name;
  final String? cover;
  final String categoryId;
  final String? plot;
  final String? cast;
  final String? director;
  final String? genre;
  final String? releaseDate;
  final String? rating;
  final bool isFavorite;

  SeriesModel({
    required this.seriesId,
    required this.name,
    this.cover,
    required this.categoryId,
    this.plot,
    this.cast,
    this.director,
    this.genre,
    this.releaseDate,
    this.rating,
    this.isFavorite = false,
  });

  factory SeriesModel.fromMap(Map<dynamic, dynamic> map) {
    return SeriesModel(
      seriesId: map['series_id']?.toString() ?? '',
      name: map['name']?.toString() ?? '',
      cover: map['cover']?.toString(),
      categoryId: map['category_id']?.toString() ?? '',
      plot: map['plot']?.toString(),
      cast: map['cast']?.toString(),
      director: map['director']?.toString(),
      genre: map['genre']?.toString(),
      releaseDate: map['releaseDate']?.toString(),
      rating: map['rating']?.toString(),
    );
  }

  SeriesModel copyWith({bool? isFavorite}) {
    return SeriesModel(
      seriesId: seriesId,
      name: name,
      cover: cover,
      categoryId: categoryId,
      plot: plot,
      cast: cast,
      director: director,
      genre: genre,
      releaseDate: releaseDate,
      rating: rating,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }
}

class EpisodeModel {
  final String id;
  final String title;
  final int episodeNum;
  final int season;
  final String? info;
  final String? movieImage;
  final String containerExtension;

  EpisodeModel({
    required this.id,
    required this.title,
    required this.episodeNum,
    required this.season,
    this.info,
    this.movieImage,
    this.containerExtension = 'mp4',
  });

  factory EpisodeModel.fromMap(Map<dynamic, dynamic> map) {
    return EpisodeModel(
      id: map['id']?.toString() ?? '',
      title: map['title']?.toString() ?? '',
      episodeNum: int.tryParse(map['episode_num']?.toString() ?? '0') ?? 0,
      season: int.tryParse(map['season']?.toString() ?? '0') ?? 0,
      info: map['info']?.toString(),
      movieImage: map['movie_image']?.toString(),
      containerExtension: map['container_extension']?.toString() ?? 'mp4',
    );
  }

  String getStreamUrl(String baseUrl, String username, String password) {
    return '$baseUrl/series/$username/$password/$id.$containerExtension';
  }
}
