class MovieModel {
  final String streamId;
  final String name;
  final String? streamIcon;
  final String categoryId;
  final String? plot;
  final String? cast;
  final String? director;
  final String? genre;
  final String? releaseDate;
  final String? rating;
  final String? duration;
  final String? containerExtension;
  final bool isFavorite;

  MovieModel({
    required this.streamId,
    required this.name,
    this.streamIcon,
    required this.categoryId,
    this.plot,
    this.cast,
    this.director,
    this.genre,
    this.releaseDate,
    this.rating,
    this.duration,
    this.containerExtension,
    this.isFavorite = false,
  });

  factory MovieModel.fromMap(Map<dynamic, dynamic> map) {
    return MovieModel(
      streamId: map['stream_id']?.toString() ?? '',
      name: map['name']?.toString() ?? '',
      streamIcon: map['stream_icon']?.toString(),
      categoryId: map['category_id']?.toString() ?? '',
      plot: map['plot']?.toString(),
      cast: map['cast']?.toString(),
      director: map['director']?.toString(),
      genre: map['genre']?.toString(),
      releaseDate: map['releaseDate']?.toString(),
      rating: map['rating']?.toString(),
      duration: map['duration']?.toString(),
      containerExtension: map['container_extension']?.toString() ?? 'mp4',
    );
  }

  String getStreamUrl(String baseUrl, String username, String password) {
    return '$baseUrl/movie/$username/$password/$streamId.${containerExtension ?? 'mp4'}';
  }

  MovieModel copyWith({bool? isFavorite}) {
    return MovieModel(
      streamId: streamId,
      name: name,
      streamIcon: streamIcon,
      categoryId: categoryId,
      plot: plot,
      cast: cast,
      director: director,
      genre: genre,
      releaseDate: releaseDate,
      rating: rating,
      duration: duration,
      containerExtension: containerExtension,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }
}
