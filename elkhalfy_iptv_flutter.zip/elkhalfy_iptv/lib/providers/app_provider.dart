import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/server_model.dart';
import '../models/channel_model.dart';
import '../models/movie_model.dart';
import '../models/series_model.dart';
import '../models/category_model.dart';
import '../services/firebase_service.dart';
import '../services/xtream_service.dart';

enum LoadingState { idle, loading, loaded, error }

class AppProvider extends ChangeNotifier {
  final SharedPreferences prefs;
  final String? savedCode;

  AppProvider({required this.prefs, this.savedCode});

  // Auth
  ServerModel? _server;
  ServerModel? get server => _server;
  bool get isLoggedIn => _server != null;

  // Xtream service
  XtreamService? _xtream;

  // Categories
  List<CategoryModel> _liveCategories = [];
  List<CategoryModel> _movieCategories = [];
  List<CategoryModel> _seriesCategories = [];
  List<CategoryModel> get liveCategories => _liveCategories;
  List<CategoryModel> get movieCategories => _movieCategories;
  List<CategoryModel> get seriesCategories => _seriesCategories;

  // Content - loaded progressively
  final List<ChannelModel> _allChannels = [];
  final List<MovieModel> _allMovies = [];
  final List<SeriesModel> _allSeries = [];
  List<ChannelModel> get allChannels => _allChannels;
  List<MovieModel> get allMovies => _allMovies;
  List<SeriesModel> get allSeries => _allSeries;

  // Favorites
  Set<String> _favChannels = {};
  Set<String> _favMovies = {};
  Set<String> _favSeries = {};

  // Loading states
  LoadingState _authState = LoadingState.idle;
  LoadingState _liveState = LoadingState.idle;
  LoadingState _movieState = LoadingState.idle;
  LoadingState _seriesState = LoadingState.idle;
  LoadingState get authState => _authState;
  LoadingState get liveState => _liveState;
  LoadingState get movieState => _movieState;
  LoadingState get seriesState => _seriesState;

  String _authError = '';
  String get authError => _authError;

  // Social links
  Map<String, String> _socialLinks = {};
  Map<String, String> get socialLinks => _socialLinks;

  // ─── Auth ─────────────────────────────────────────────────────────
  Future<bool> login(String code) async {
    _authState = LoadingState.loading;
    _authError = '';
    notifyListeners();

    final serverModel = await FirebaseService.validateCode(code);
    if (serverModel == null) {
      _authState = LoadingState.error;
      _authError = 'كود التفعيل غير صحيح أو منتهي الصلاحية';
      notifyListeners();
      return false;
    }

    if (serverModel.isExpired) {
      _authState = LoadingState.error;
      _authError = 'انتهت صلاحية الاشتراك';
      notifyListeners();
      return false;
    }

    _server = serverModel;
    _xtream = XtreamService(
      baseUrl: serverModel.baseUrl,
      username: serverModel.username,
      password: serverModel.password,
    );
    _socialLinks = serverModel.socialLinks;

    await prefs.setString('activation_code', code.toUpperCase());
    _loadFavorites();

    _authState = LoadingState.loaded;
    notifyListeners();
    return true;
  }

  Future<bool> autoLogin() async {
    if (savedCode == null) return false;
    return login(savedCode!);
  }

  void logout() {
    _server = null;
    _xtream = null;
    _allChannels.clear();
    _allMovies.clear();
    _allSeries.clear();
    _liveCategories = [];
    _movieCategories = [];
    _seriesCategories = [];
    _authState = LoadingState.idle;
    _liveState = LoadingState.idle;
    _movieState = LoadingState.idle;
    _seriesState = LoadingState.idle;
    prefs.remove('activation_code');
    notifyListeners();
  }

  // ─── Load Content ──────────────────────────────────────────────────
  Future<void> loadLiveContent() async {
    if (_xtream == null || _liveState == LoadingState.loading) return;
    _liveState = LoadingState.loading;
    _allChannels.clear();
    notifyListeners();

    try {
      final cats = await _xtream!.getLiveCategories();
      _liveCategories = [
        CategoryModel(categoryId: '', categoryName: 'All', count: 0),
        CategoryModel(categoryId: 'fav', categoryName: 'Favorites', count: 0),
        ...cats,
      ];
      notifyListeners();

      // Load channels progressively by category
      final allStreams = await _xtream!.getLiveStreams();
      // Count per category
      final catMap = <String, int>{};
      for (final ch in allStreams) {
        catMap[ch.categoryId] = (catMap[ch.categoryId] ?? 0) + 1;
      }
      for (final cat in _liveCategories) {
        cat.count = catMap[cat.categoryId] ?? 0;
      }
      _liveCategories.first.count = allStreams.length;

      // Add channels progressively in batches
      const batchSize = 50;
      for (int i = 0; i < allStreams.length; i += batchSize) {
        final end = (i + batchSize > allStreams.length) ? allStreams.length : i + batchSize;
        final batch = allStreams.sublist(i, end);
        for (final ch in batch) {
          _allChannels.add(ch.copyWith(isFavorite: _favChannels.contains(ch.streamId)));
        }
        notifyListeners();
        await Future.delayed(const Duration(milliseconds: 10));
      }
      _liveState = LoadingState.loaded;
    } catch (e) {
      _liveState = LoadingState.error;
    }
    notifyListeners();
  }

  Future<void> loadMovieContent() async {
    if (_xtream == null || _movieState == LoadingState.loading) return;
    _movieState = LoadingState.loading;
    _allMovies.clear();
    notifyListeners();

    try {
      final cats = await _xtream!.getVodCategories();
      _movieCategories = [
        CategoryModel(categoryId: '', categoryName: 'All', count: 0),
        CategoryModel(categoryId: 'fav', categoryName: 'Favorites', count: 0),
        ...cats,
      ];
      notifyListeners();

      final allStreams = await _xtream!.getVodStreams();
      final catMap = <String, int>{};
      for (final m in allStreams) {
        catMap[m.categoryId] = (catMap[m.categoryId] ?? 0) + 1;
      }
      for (final cat in _movieCategories) {
        cat.count = catMap[cat.categoryId] ?? 0;
      }
      _movieCategories.first.count = allStreams.length;

      const batchSize = 30;
      for (int i = 0; i < allStreams.length; i += batchSize) {
        final end = (i + batchSize > allStreams.length) ? allStreams.length : i + batchSize;
        final batch = allStreams.sublist(i, end);
        for (final m in batch) {
          _allMovies.add(m.copyWith(isFavorite: _favMovies.contains(m.streamId)));
        }
        notifyListeners();
        await Future.delayed(const Duration(milliseconds: 10));
      }
      _movieState = LoadingState.loaded;
    } catch (e) {
      _movieState = LoadingState.error;
    }
    notifyListeners();
  }

  Future<void> loadSeriesContent() async {
    if (_xtream == null || _seriesState == LoadingState.loading) return;
    _seriesState = LoadingState.loading;
    _allSeries.clear();
    notifyListeners();

    try {
      final cats = await _xtream!.getSeriesCategories();
      _seriesCategories = [
        CategoryModel(categoryId: '', categoryName: 'All', count: 0),
        CategoryModel(categoryId: 'fav', categoryName: 'Favorites', count: 0),
        ...cats,
      ];
      notifyListeners();

      final allStreams = await _xtream!.getSeries();
      final catMap = <String, int>{};
      for (final s in allStreams) {
        catMap[s.categoryId] = (catMap[s.categoryId] ?? 0) + 1;
      }
      for (final cat in _seriesCategories) {
        cat.count = catMap[cat.categoryId] ?? 0;
      }
      _seriesCategories.first.count = allStreams.length;

      const batchSize = 30;
      for (int i = 0; i < allStreams.length; i += batchSize) {
        final end = (i + batchSize > allStreams.length) ? allStreams.length : i + batchSize;
        final batch = allStreams.sublist(i, end);
        for (final s in batch) {
          _allSeries.add(s.copyWith(isFavorite: _favSeries.contains(s.seriesId)));
        }
        notifyListeners();
        await Future.delayed(const Duration(milliseconds: 10));
      }
      _seriesState = LoadingState.loaded;
    } catch (e) {
      _seriesState = LoadingState.error;
    }
    notifyListeners();
  }

  Future<Map<String, List<EpisodeModel>>> getSeriesEpisodes(String seriesId) async {
    if (_xtream == null) return {};
    return _xtream!.getSeriesInfo(seriesId);
  }

  // ─── URL builders ──────────────────────────────────────────────────
  String getLiveUrl(String streamId) =>
      _xtream?.getLiveUrl(streamId) ?? '';
  String getMovieUrl(String streamId, [String ext = 'mp4']) =>
      _xtream?.getMovieUrl(streamId, ext) ?? '';
  String getEpisodeUrl(String episodeId, [String ext = 'mp4']) =>
      _xtream?.getEpisodeUrl(episodeId, ext) ?? '';

  // ─── Favorites ─────────────────────────────────────────────────────
  void _loadFavorites() {
    _favChannels = Set.from(prefs.getStringList('fav_channels') ?? []);
    _favMovies = Set.from(prefs.getStringList('fav_movies') ?? []);
    _favSeries = Set.from(prefs.getStringList('fav_series') ?? []);
  }

  void toggleChannelFav(String id) {
    if (_favChannels.contains(id)) {
      _favChannels.remove(id);
    } else {
      _favChannels.add(id);
    }
    prefs.setStringList('fav_channels', _favChannels.toList());
    final idx = _allChannels.indexWhere((c) => c.streamId == id);
    if (idx >= 0) {
      _allChannels[idx] = _allChannels[idx].copyWith(isFavorite: _favChannels.contains(id));
    }
    notifyListeners();
  }

  void toggleMovieFav(String id) {
    if (_favMovies.contains(id)) {
      _favMovies.remove(id);
    } else {
      _favMovies.add(id);
    }
    prefs.setStringList('fav_movies', _favMovies.toList());
    final idx = _allMovies.indexWhere((m) => m.streamId == id);
    if (idx >= 0) {
      _allMovies[idx] = _allMovies[idx].copyWith(isFavorite: _favMovies.contains(id));
    }
    notifyListeners();
  }

  void toggleSeriesFav(String id) {
    if (_favSeries.contains(id)) {
      _favSeries.remove(id);
    } else {
      _favSeries.add(id);
    }
    prefs.setStringList('fav_series', _favSeries.toList());
    final idx = _allSeries.indexWhere((s) => s.seriesId == id);
    if (idx >= 0) {
      _allSeries[idx] = _allSeries[idx].copyWith(isFavorite: _favSeries.contains(id));
    }
    notifyListeners();
  }

  // ─── Filter helpers ────────────────────────────────────────────────
  List<ChannelModel> getChannelsByCategory(String catId) {
    if (catId.isEmpty) return _allChannels;
    if (catId == 'fav') return _allChannels.where((c) => c.isFavorite).toList();
    return _allChannels.where((c) => c.categoryId == catId).toList();
  }

  List<MovieModel> getMoviesByCategory(String catId) {
    if (catId.isEmpty) return _allMovies;
    if (catId == 'fav') return _allMovies.where((m) => m.isFavorite).toList();
    return _allMovies.where((m) => m.categoryId == catId).toList();
  }

  List<SeriesModel> getSeriesByCategory(String catId) {
    if (catId.isEmpty) return _allSeries;
    if (catId == 'fav') return _allSeries.where((s) => s.isFavorite).toList();
    return _allSeries.where((s) => s.categoryId == catId).toList();
  }

  List<ChannelModel> searchChannels(String query) {
    final q = query.toLowerCase();
    return _allChannels.where((c) => c.name.toLowerCase().contains(q)).toList();
  }

  List<MovieModel> searchMovies(String query) {
    final q = query.toLowerCase();
    return _allMovies.where((m) => m.name.toLowerCase().contains(q)).toList();
  }

  List<SeriesModel> searchSeries(String query) {
    final q = query.toLowerCase();
    return _allSeries.where((s) => s.name.toLowerCase().contains(q)).toList();
  }
}
