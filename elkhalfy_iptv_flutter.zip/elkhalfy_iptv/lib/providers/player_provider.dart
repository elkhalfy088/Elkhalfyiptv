import 'package:flutter/foundation.dart';

enum PlayerType { live, movie, series }

class PlayerProvider extends ChangeNotifier {
  PlayerType _playerType = PlayerType.live;
  String _currentUrl = '';
  String _currentTitle = '';
  bool _isFullscreen = false;

  PlayerType get playerType => _playerType;
  String get currentUrl => _currentUrl;
  String get currentTitle => _currentTitle;
  bool get isFullscreen => _isFullscreen;

  void setPlayer({
    required PlayerType type,
    required String url,
    required String title,
  }) {
    _playerType = type;
    _currentUrl = url;
    _currentTitle = title;
    notifyListeners();
  }

  void toggleFullscreen() {
    _isFullscreen = !_isFullscreen;
    notifyListeners();
  }

  void setFullscreen(bool value) {
    _isFullscreen = value;
    notifyListeners();
  }
}
