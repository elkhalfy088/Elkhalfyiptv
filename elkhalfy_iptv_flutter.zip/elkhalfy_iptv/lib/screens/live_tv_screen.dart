import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../models/channel_model.dart';
import '../models/category_model.dart';
import '../utils/app_theme.dart';
import '../widgets/category_sidebar.dart';
import '../widgets/channel_card.dart';
import 'live_player_screen.dart';

class LiveTVScreen extends StatefulWidget {
  final String searchQuery;
  const LiveTVScreen({super.key, this.searchQuery = ''});
  @override
  State<LiveTVScreen> createState() => _LiveTVScreenState();
}

class _LiveTVScreenState extends State<LiveTVScreen> {
  String _selectedCatId = '';
  final _catSearchCtrl = TextEditingController();
  String _catSearch = '';

  @override
  void dispose() {
    _catSearchCtrl.dispose();
    super.dispose();
  }

  void _openPlayer(ChannelModel ch) {
    final provider = context.read<AppProvider>();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => LivePlayerScreen(
          channel: ch,
          streamUrl: provider.getLiveUrl(ch.streamId),
          allChannels: provider.getChannelsByCategory(_selectedCatId),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(builder: (_, prov, __) {
      final isLoading = prov.liveState == LoadingState.loading;
      final isError = prov.liveState == LoadingState.error;

      final categories = prov.liveCategories;
      final filteredCats = _catSearch.isEmpty
          ? categories
          : categories
              .where((c) => c.categoryName.toLowerCase().contains(_catSearch.toLowerCase()))
              .toList();

      // Content
      List<ChannelModel> channels;
      if (widget.searchQuery.isNotEmpty) {
        channels = prov.searchChannels(widget.searchQuery);
      } else {
        channels = prov.getChannelsByCategory(_selectedCatId);
      }

      final catName = categories
              .firstWhere((c) => c.categoryId == _selectedCatId,
                  orElse: () => CategoryModel(categoryId: '', categoryName: 'All'))
              .categoryName;

      final isTablet = MediaQuery.of(context).size.width > 600;

      return Row(
        children: [
          // Sidebar
          SizedBox(
            width: isTablet ? 280 : 220,
            child: CategorySidebar(
              categories: filteredCats,
              selectedId: _selectedCatId,
              searchController: _catSearchCtrl,
              searchHint: 'Search Categories',
              onSearch: (v) => setState(() => _catSearch = v),
              onSelect: (id) => setState(() => _selectedCatId = id),
            ),
          ),
          // Main
          Expanded(
            child: Column(
              children: [
                // Header
                if (widget.searchQuery.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Text(
                      catName,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                // Content
                Expanded(
                  child: isError
                      ? _ErrorWidget(onRetry: prov.loadLiveContent)
                      : isLoading && channels.isEmpty
                          ? _LoadingGrid()
                          : channels.isEmpty
                              ? const _EmptyWidget(message: 'لا توجد قنوات')
                              : GridView.builder(
                                  padding: const EdgeInsets.all(8),
                                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: isTablet ? 5 : 3,
                                    childAspectRatio: 1.5,
                                    crossAxisSpacing: 6,
                                    mainAxisSpacing: 6,
                                  ),
                                  itemCount: channels.length,
                                  itemBuilder: (_, i) => ChannelCard(
                                    channel: channels[i],
                                    onTap: () => _openPlayer(channels[i]),
                                    onFav: () => prov.toggleChannelFav(channels[i].streamId),
                                  ),
                                ),
                ),
                // Loading indicator at bottom
                if (isLoading && channels.isNotEmpty)
                  const LinearProgressIndicator(
                    backgroundColor: AppTheme.bgCard,
                    valueColor: AlwaysStoppedAnimation(AppTheme.primary),
                  ),
              ],
            ),
          ),
        ],
      );
    });
  }
}

class _LoadingGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 1.5,
        crossAxisSpacing: 6,
        mainAxisSpacing: 6,
      ),
      itemCount: 12,
      itemBuilder: (_, __) => Container(
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}

class _ErrorWidget extends StatelessWidget {
  final VoidCallback onRetry;
  const _ErrorWidget({required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.wifi_off_rounded, color: AppTheme.textMuted, size: 48),
          const SizedBox(height: 12),
          const Text('فشل تحميل القنوات',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 15)),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
        ],
      ),
    );
  }
}

class _EmptyWidget extends StatelessWidget {
  final String message;
  const _EmptyWidget({required this.message});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.inbox_rounded, color: AppTheme.textMuted, size: 48),
          const SizedBox(height: 12),
          Text(message, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 15)),
        ],
      ),
    );
  }
}
