import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../providers/app_provider.dart';
import '../utils/app_theme.dart';
import 'live_tv_screen.dart';
import 'movies_screen.dart';
import 'series_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tabIndex = 0;
  bool _searchOpen = false;
  final _searchCtrl = TextEditingController();
  String _searchQuery = '';

  static const _tabs = ['LIVE TV', 'Movies', 'Series'];
  static const _tabIcons = [
    Icons.live_tv_rounded,
    Icons.movie_rounded,
    Icons.video_library_rounded,
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadTab(0));
  }

  void _loadTab(int index) {
    final p = context.read<AppProvider>();
    switch (index) {
      case 0:
        if (p.liveState == LoadingState.idle) p.loadLiveContent();
        break;
      case 1:
        if (p.movieState == LoadingState.idle) p.loadMovieContent();
        break;
      case 2:
        if (p.seriesState == LoadingState.idle) p.loadSeriesContent();
        break;
    }
  }

  void _switchTab(int i) {
    setState(() {
      _tabIndex = i;
      _searchQuery = '';
      _searchCtrl.clear();
      _searchOpen = false;
    });
    _loadTab(i);
  }

  void _showMenu() {
    final links = context.read<AppProvider>().socialLinks;
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.bgCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _SocialMenu(
        links: links,
        onLogout: () {
          Navigator.pop(context);
          context.read<AppProvider>().logout();
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const LoginScreen()),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width > 600;
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        backgroundColor: AppTheme.bgDark,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.all(10),
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [AppTheme.primary, AppTheme.accent],
              ),
            ),
            child: const Center(
              child: Text('K',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
        ),
        title: _searchOpen
            ? TextField(
                controller: _searchCtrl,
                autofocus: true,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: _tabIndex == 0 ? 'بحث عن قناة...' : _tabIndex == 1 ? 'بحث عن فيلم...' : 'بحث عن مسلسل...',
                  hintStyle: const TextStyle(color: AppTheme.textMuted),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                ),
                onChanged: (v) => setState(() => _searchQuery = v),
              )
            : null,
        centerTitle: true,
        actions: [
          // Tab pills — shown centered on non-tablet
          if (!isTablet && !_searchOpen)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _TabPills(
                  selected: _tabIndex,
                  onSelect: _switchTab,
                ),
              ),
            ),
          IconButton(
            icon: Icon(_searchOpen ? Icons.close : Icons.search_rounded,
                color: Colors.white),
            onPressed: () {
              setState(() {
                _searchOpen = !_searchOpen;
                if (!_searchOpen) {
                  _searchQuery = '';
                  _searchCtrl.clear();
                }
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            onPressed: _showMenu,
          ),
        ],
      ),
      body: Column(
        children: [
          // Tablet: top tab bar
          if (isTablet)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: _TabPills(selected: _tabIndex, onSelect: _switchTab),
            ),
          Expanded(
            child: IndexedStack(
              index: _tabIndex,
              children: [
                LiveTVScreen(searchQuery: _tabIndex == 0 ? _searchQuery : ''),
                MoviesScreen(searchQuery: _tabIndex == 1 ? _searchQuery : ''),
                SeriesScreen(searchQuery: _tabIndex == 2 ? _searchQuery : ''),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TabPills extends StatelessWidget {
  final int selected;
  final void Function(int) onSelect;
  const _TabPills({required this.selected, required this.onSelect});

  static const _labels = ['LIVE TV', 'Movies', 'Series'];
  static const _icons = [
    Icons.live_tv_rounded,
    Icons.movie_rounded,
    Icons.video_library_rounded,
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_labels.length, (i) {
        final active = selected == i;
        return GestureDetector(
          onTap: () => onSelect(i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: active ? AppTheme.primary : AppTheme.bgCard,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: active ? AppTheme.primary : AppTheme.cardBorder,
                width: 0.8,
              ),
              boxShadow: active
                  ? [BoxShadow(color: AppTheme.primary.withOpacity(0.35), blurRadius: 12)]
                  : null,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(_icons[i],
                    size: 14,
                    color: active ? Colors.white : AppTheme.textSecondary),
                const SizedBox(width: 5),
                Text(
                  _labels[i],
                  style: TextStyle(
                    color: active ? Colors.white : AppTheme.textSecondary,
                    fontSize: 13,
                    fontWeight: active ? FontWeight.w700 : FontWeight.normal,
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class _SocialMenu extends StatelessWidget {
  final Map<String, String> links;
  final VoidCallback onLogout;
  const _SocialMenu({required this.links, required this.onLogout});

  @override
  Widget build(BuildContext context) {
    final items = <_SocialItem>[];
    links.forEach((k, v) {
      if (v.isNotEmpty) {
        items.add(_SocialItem(label: k, url: v));
      }
    });

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('روابط التواصل الاجتماعي',
              style: TextStyle(
                  color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          if (items.isEmpty)
            const Text('لا توجد روابط متاحة',
                style: TextStyle(color: AppTheme.textMuted)),
          ...items.map((item) => _SocialTile(item: item)),
          const Divider(color: AppTheme.divider),
          ListTile(
            leading: const Icon(Icons.logout, color: AppTheme.liveTag),
            title: const Text('تسجيل الخروج',
                style: TextStyle(color: AppTheme.liveTag, fontWeight: FontWeight.w600)),
            onTap: onLogout,
            contentPadding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }
}

class _SocialItem {
  final String label;
  final String url;
  _SocialItem({required this.label, required this.url});
}

class _SocialTile extends StatelessWidget {
  final _SocialItem item;
  const _SocialTile({required this.item});

  IconData _icon(String label) {
    final l = label.toLowerCase();
    if (l.contains('telegram')) return Icons.telegram;
    if (l.contains('whatsapp')) return Icons.chat;
    if (l.contains('youtube')) return Icons.play_circle_filled;
    if (l.contains('facebook')) return Icons.facebook;
    if (l.contains('instagram')) return Icons.camera_alt;
    if (l.contains('twitter') || l.contains('x.com')) return Icons.close;
    return Icons.link;
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: AppTheme.primary.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(_icon(item.label), color: AppTheme.primary, size: 20),
      ),
      title: Text(item.label,
          style: const TextStyle(color: Colors.white, fontSize: 14)),
      subtitle: Text(item.url,
          style: const TextStyle(color: AppTheme.textMuted, fontSize: 11),
          maxLines: 1,
          overflow: TextOverflow.ellipsis),
      onTap: () async {
        final uri = Uri.tryParse(item.url);
        if (uri != null && await canLaunchUrl(uri)) {
          launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      },
      contentPadding: EdgeInsets.zero,
    );
  }
}
