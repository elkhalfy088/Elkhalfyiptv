import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/series_model.dart';
import '../providers/app_provider.dart';
import '../utils/app_theme.dart';
import '../widgets/network_image_cached.dart';
import 'vod_player_screen.dart';

class SeriesDetailScreen extends StatefulWidget {
  final SeriesModel series;
  const SeriesDetailScreen({super.key, required this.series});
  @override
  State<SeriesDetailScreen> createState() => _SeriesDetailScreenState();
}

class _SeriesDetailScreenState extends State<SeriesDetailScreen> {
  Map<String, List<EpisodeModel>> _episodes = {};
  bool _loading = true;
  String _selectedSeason = '';

  @override
  void initState() {
    super.initState();
    _loadEpisodes();
  }

  Future<void> _loadEpisodes() async {
    final prov = context.read<AppProvider>();
    final eps = await prov.getSeriesEpisodes(widget.series.seriesId);
    if (!mounted) return;
    setState(() {
      _episodes = eps;
      _loading = false;
      if (eps.isNotEmpty) _selectedSeason = eps.keys.first;
    });
  }

  void _playEpisode(EpisodeModel ep) {
    final prov = context.read<AppProvider>();
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => VodPlayerScreen(
        title: '${widget.series.name} - E${ep.episodeNum}',
        streamUrl: prov.getEpisodeUrl(ep.id, ep.containerExtension),
        coverUrl: ep.movieImage ?? widget.series.cover,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final seasons = _episodes.keys.toList()..sort();

    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      body: CustomScrollView(
        slivers: [
          // App bar with cover
          SliverAppBar(
            backgroundColor: AppTheme.bgDark,
            expandedHeight: 220,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                widget.series.name,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  if (widget.series.cover != null && widget.series.cover!.isNotEmpty)
                    CachedImage(url: widget.series.cover!, fit: BoxFit.cover),
                  Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, AppTheme.bgDark],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Info
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.series.genre != null && widget.series.genre!.isNotEmpty)
                    Text(widget.series.genre!,
                        style: const TextStyle(color: AppTheme.primary, fontSize: 12)),
                  if (widget.series.plot != null && widget.series.plot!.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(widget.series.plot!,
                        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13, height: 1.5),
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis),
                  ],
                ],
              ),
            ),
          ),
          // Season tabs
          if (!_loading && seasons.isNotEmpty)
            SliverToBoxAdapter(
              child: SizedBox(
                height: 44,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: seasons.length,
                  itemBuilder: (_, i) {
                    final s = seasons[i];
                    final selected = s == _selectedSeason;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedSeason = s),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: selected ? AppTheme.primary : AppTheme.bgCard,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: selected ? AppTheme.primary : AppTheme.cardBorder),
                        ),
                        child: Text(
                          'Season $s',
                          style: TextStyle(
                              color: selected ? Colors.white : AppTheme.textSecondary,
                              fontSize: 13,
                              fontWeight: selected ? FontWeight.w700 : FontWeight.normal),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          // Episodes
          if (_loading)
            SliverToBoxAdapter(
              child: const Padding(
                padding: EdgeInsets.all(40),
                child: Center(
                    child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(AppTheme.primary))),
              ),
            )
          else if (_selectedSeason.isNotEmpty && _episodes[_selectedSeason] != null)
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (_, i) {
                  final ep = _episodes[_selectedSeason]![i];
                  return ListTile(
                    onTap: () => _playEpisode(ep),
                    leading: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppTheme.cardBorder),
                      ),
                      child: ep.movieImage != null && ep.movieImage!.isNotEmpty
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: CachedImage(url: ep.movieImage!, fit: BoxFit.cover),
                            )
                          : const Icon(Icons.play_circle_outline, color: AppTheme.primary),
                    ),
                    title: Text('Episode ${ep.episodeNum}',
                        style: const TextStyle(color: Colors.white, fontSize: 14)),
                    subtitle: ep.title.isNotEmpty
                        ? Text(ep.title, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12))
                        : null,
                    trailing: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.play_arrow_rounded, color: AppTheme.primary, size: 20),
                    ),
                  );
                },
                childCount: _episodes[_selectedSeason]?.length ?? 0,
              ),
            ),
        ],
      ),
    );
  }
}
