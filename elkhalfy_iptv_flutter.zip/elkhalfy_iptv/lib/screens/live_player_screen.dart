import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:better_player/better_player.dart';
import '../models/channel_model.dart';
import '../utils/app_theme.dart';
import '../widgets/network_image_cached.dart';

class LivePlayerScreen extends StatefulWidget {
  final ChannelModel channel;
  final String streamUrl;
  final List<ChannelModel> allChannels;

  const LivePlayerScreen({
    super.key,
    required this.channel,
    required this.streamUrl,
    required this.allChannels,
  });

  @override
  State<LivePlayerScreen> createState() => _LivePlayerScreenState();
}

class _LivePlayerScreenState extends State<LivePlayerScreen> {
  BetterPlayerController? _controller;
  late ChannelModel _current;
  bool _isFullscreen = false;

  @override
  void initState() {
    super.initState();
    _current = widget.channel;
    _initPlayer(widget.streamUrl);
  }

  void _initPlayer(String url) {
    _controller?.dispose();
    final source = BetterPlayerDataSource(
      BetterPlayerDataSourceType.network,
      url,
      liveStream: true,
      bufferingConfiguration: const BetterPlayerBufferingConfiguration(
        minBufferMs: 2000,
        maxBufferMs: 8000,
        bufferForPlaybackMs: 1000,
        bufferForPlaybackAfterRebufferMs: 2000,
      ),
    );

    _controller = BetterPlayerController(
      BetterPlayerConfiguration(
        autoPlay: true,
        looping: false,
        fit: BoxFit.contain,
        aspectRatio: 16 / 9,
        fullScreenByDefault: false,
        allowedScreenSleep: false,
        controlsConfiguration: const BetterPlayerControlsConfiguration(
          // No controls for live TV
          showControls: false,
          enableSkips: false,
        ),
        errorBuilder: (ctx, msg) => Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, color: Colors.white, size: 48),
              const SizedBox(height: 8),
              Text(
                'فشل تشغيل القناة\n${msg ?? ''}',
                style: const TextStyle(color: Colors.white70),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
      betterPlayerDataSource: source,
    );

    setState(() {});
  }

  void _switchChannel(ChannelModel ch, String url) {
    setState(() => _current = ch);
    _initPlayer(url);
  }

  void _toggleFullscreen() {
    if (_isFullscreen) {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    } else {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
    setState(() => _isFullscreen = !_isFullscreen);
  }

  @override
  void dispose() {
    _controller?.dispose();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width > 600;

    if (_isFullscreen) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            if (_controller != null)
              Center(child: BetterPlayer(controller: _controller!)),
            Positioned(
              top: 16,
              left: 16,
              child: _controlBtn(Icons.fullscreen_exit, _toggleFullscreen),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      body: SafeArea(
        child: Column(
          children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Row(
                      children: const [
                        Icon(Icons.chevron_left, color: Colors.white, size: 28),
                        Text('Back', style: TextStyle(color: Colors.white, fontSize: 15)),
                      ],
                    ),
                  ),
                  const Spacer(),
                  // Date/time
                  Text(
                    _formatDateTime(),
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
                  ),
                ],
              ),
            ),
            const Divider(color: AppTheme.divider, height: 1),
            Expanded(
              child: Row(
                children: [
                  // Channel list
                  SizedBox(
                    width: isTablet ? 300 : 220,
                    child: _ChannelListPanel(
                      channels: widget.allChannels,
                      current: _current,
                      onSelect: (ch, url) => _switchChannel(ch, url),
                    ),
                  ),
                  // Player + info
                  Expanded(
                    child: Column(
                      children: [
                        // Player
                        AspectRatio(
                          aspectRatio: 16 / 9,
                          child: Stack(
                            children: [
                              Container(color: Colors.black),
                              if (_controller != null)
                                BetterPlayer(controller: _controller!),
                              // Fullscreen button
                              Positioned(
                                bottom: 8,
                                right: 8,
                                child: _controlBtn(Icons.fullscreen, _toggleFullscreen),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        // Channel info
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: AppTheme.liveTag,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Text(
                                  'Live TV',
                                  style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700),
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                _current.name,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
                                textAlign: TextAlign.right,
                              ),
                              const SizedBox(height: 4),
                              const Text(
                                'No Information',
                                style: TextStyle(color: AppTheme.textMuted, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _controlBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: Colors.black54,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }

  String _formatDateTime() {
    final now = DateTime.now();
    final h = now.hour.toString().padLeft(2, '0');
    final m = now.minute.toString().padLeft(2, '0');
    final months = ['jan', 'fév', 'mars', 'avr', 'mai', 'juin', 'juil', 'août', 'sep', 'oct', 'nov', 'déc'];
    return '$h:$m ${now.hour < 12 ? 'AM' : 'PM'} | ${months[now.month - 1]}. ${now.day} ${now.year}';
  }
}

class _ChannelListPanel extends StatefulWidget {
  final List<ChannelModel> channels;
  final ChannelModel current;
  final void Function(ChannelModel, String) onSelect;

  const _ChannelListPanel({
    required this.channels,
    required this.current,
    required this.onSelect,
  });

  @override
  State<_ChannelListPanel> createState() => _ChannelListPanelState();
}

class _ChannelListPanelState extends State<_ChannelListPanel> {
  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToCurrent());
  }

  void _scrollToCurrent() {
    final idx = widget.channels.indexWhere((c) => c.streamId == widget.current.streamId);
    if (idx >= 0 && _scrollCtrl.hasClients) {
      _scrollCtrl.animateTo(
        idx * 60.0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Category navigator
    return Column(
      children: [
        // Mini header
        Container(
          height: 48,
          decoration: const BoxDecoration(
            color: AppTheme.bgSidebar,
            border: Border(bottom: BorderSide(color: AppTheme.divider)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Icon(Icons.chevron_left, color: Colors.white),
              Expanded(
                child: Text(
                  widget.current.categoryId,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.white),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            controller: _scrollCtrl,
            itemCount: widget.channels.length,
            itemExtent: 64,
            itemBuilder: (_, i) {
              final ch = widget.channels[i];
              final isSelected = ch.streamId == widget.current.streamId;
              return GestureDetector(
                onTap: () => widget.onSelect(ch, ''),
                child: Container(
                  color: isSelected ? AppTheme.primary.withOpacity(0.15) : Colors.transparent,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 36,
                        child: Text(
                          ch.num.toString(),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: isSelected ? AppTheme.primary : AppTheme.textMuted,
                            fontSize: 11,
                          ),
                        ),
                      ),
                      // Icon
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: AppTheme.bgCard,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: isSelected ? AppTheme.primary : AppTheme.cardBorder,
                            width: isSelected ? 1.5 : 0.5,
                          ),
                        ),
                        child: ch.streamIcon != null && ch.streamIcon!.isNotEmpty
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: CachedImage(url: ch.streamIcon!, fit: BoxFit.contain),
                              )
                            : const Icon(Icons.live_tv_rounded,
                                color: AppTheme.textMuted, size: 20),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              ch.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: isSelected ? Colors.white : AppTheme.textSecondary,
                                fontSize: 13,
                                fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
                              ),
                            ),
                            const Text(
                              'No Information',
                              style: TextStyle(color: AppTheme.textMuted, fontSize: 10),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
