import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:better_player/better_player.dart';
import '../utils/app_theme.dart';
import '../widgets/network_image_cached.dart';

class VodPlayerScreen extends StatefulWidget {
  final String title;
  final String streamUrl;
  final String? coverUrl;
  final String? plot;
  final String? genre;
  final String? rating;
  final String? duration;

  const VodPlayerScreen({
    super.key,
    required this.title,
    required this.streamUrl,
    this.coverUrl,
    this.plot,
    this.genre,
    this.rating,
    this.duration,
  });

  @override
  State<VodPlayerScreen> createState() => _VodPlayerScreenState();
}

class _VodPlayerScreenState extends State<VodPlayerScreen> {
  BetterPlayerController? _controller;
  bool _isFullscreen = false;

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  void _initPlayer() {
    final source = BetterPlayerDataSource(
      BetterPlayerDataSourceType.network,
      widget.streamUrl,
      bufferingConfiguration: const BetterPlayerBufferingConfiguration(
        minBufferMs: 3000,
        maxBufferMs: 20000,
        bufferForPlaybackMs: 1500,
        bufferForPlaybackAfterRebufferMs: 3000,
      ),
    );

    _controller = BetterPlayerController(
      BetterPlayerConfiguration(
        autoPlay: true,
        looping: false,
        fit: BoxFit.contain,
        aspectRatio: 16 / 9,
        allowedScreenSleep: false,
        controlsConfiguration: BetterPlayerControlsConfiguration(
          enableFullscreen: true,
          enablePlayPause: true,
          enableMute: true,
          enableSkips: true,
          skipForwardTimeInMilliseconds: 10000,
          skipBackTimeInMilliseconds: 10000,
          progressBarPlayedColor: AppTheme.primary,
          progressBarHandleColor: AppTheme.accent,
          progressBarBufferedColor: AppTheme.primary.withOpacity(0.3),
          progressBarBackgroundColor: Colors.white24,
          iconsColor: Colors.white,
          playIcon: Icons.play_arrow_rounded,
          pauseIcon: Icons.pause_rounded,
          controlBarColor: Colors.black.withOpacity(0.7),
          loadingColor: AppTheme.primary,
          overflowMenuIcon: Icons.more_vert,
          muteIcon: Icons.volume_off_rounded,
          unMuteIcon: Icons.volume_up_rounded,
          fullscreenEnableIcon: Icons.fullscreen_rounded,
          fullscreenDisableIcon: Icons.fullscreen_exit_rounded,
        ),
        placeholder: widget.coverUrl != null
            ? CachedImage(url: widget.coverUrl!, fit: BoxFit.cover)
            : Container(color: Colors.black),
        errorBuilder: (ctx, msg) => Container(
          color: Colors.black,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline, color: Colors.white, size: 48),
                const SizedBox(height: 8),
                Text(
                  'فشل تشغيل الفيلم\n${msg ?? ''}',
                  style: const TextStyle(color: Colors.white70),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _initPlayer,
                  child: const Text('إعادة المحاولة'),
                ),
              ],
            ),
          ),
        ),
      ),
      betterPlayerDataSource: source,
    );

    setState(() {});
  }

  @override
  void dispose() {
    _controller?.dispose();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            // Player
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Stack(
                children: [
                  Container(color: Colors.black),
                  if (_controller != null)
                    BetterPlayer(controller: _controller!),
                ],
              ),
            ),
            // Info panel
            Expanded(
              child: Container(
                color: AppTheme.bgDark,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back, color: Colors.white),
                            onPressed: () => Navigator.pop(context),
                          ),
                          Expanded(
                            child: Text(
                              widget.title,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      // Meta tags
                      Wrap(
                        spacing: 8,
                        runSpacing: 6,
                        children: [
                          if (widget.genre != null && widget.genre!.isNotEmpty)
                            _MetaChip(label: widget.genre!),
                          if (widget.rating != null && widget.rating!.isNotEmpty)
                            _MetaChip(label: '⭐ ${widget.rating}', color: Colors.amber.shade700),
                          if (widget.duration != null && widget.duration!.isNotEmpty)
                            _MetaChip(label: '⏱ ${widget.duration}'),
                        ],
                      ),
                      if (widget.plot != null && widget.plot!.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        const Text('القصة',
                            style: TextStyle(
                                color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        Text(widget.plot!,
                            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13, height: 1.5)),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final String label;
  final Color? color;
  const _MetaChip({required this.label, this.color});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: (color ?? AppTheme.primary).withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: (color ?? AppTheme.primary).withOpacity(0.4)),
      ),
      child: Text(label,
          style: TextStyle(color: color ?? AppTheme.primary, fontSize: 11, fontWeight: FontWeight.w600)),
    );
  }
}
