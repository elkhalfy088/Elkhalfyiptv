import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../models/series_model.dart';
import '../models/category_model.dart';
import '../utils/app_theme.dart';
import '../widgets/category_sidebar.dart';
import '../widgets/media_card.dart';
import 'series_detail_screen.dart';

class SeriesScreen extends StatefulWidget {
  final String searchQuery;
  const SeriesScreen({super.key, this.searchQuery = ''});
  @override
  State<SeriesScreen> createState() => _SeriesScreenState();
}

class _SeriesScreenState extends State<SeriesScreen> {
  String _selectedCatId = '';
  final _catSearchCtrl = TextEditingController();
  String _catSearch = '';

  @override
  void dispose() {
    _catSearchCtrl.dispose();
    super.dispose();
  }

  void _openSeries(SeriesModel series) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => SeriesDetailScreen(series: series),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(builder: (_, prov, __) {
      final isLoading = prov.seriesState == LoadingState.loading;
      final isError = prov.seriesState == LoadingState.error;
      final categories = prov.seriesCategories;
      final filteredCats = _catSearch.isEmpty
          ? categories
          : categories.where((c) => c.categoryName.toLowerCase().contains(_catSearch.toLowerCase())).toList();

      List<SeriesModel> series;
      if (widget.searchQuery.isNotEmpty) {
        series = prov.searchSeries(widget.searchQuery);
      } else {
        series = prov.getSeriesByCategory(_selectedCatId);
      }

      final catName = categories
          .firstWhere((c) => c.categoryId == _selectedCatId,
              orElse: () => CategoryModel(categoryId: '', categoryName: 'All'))
          .categoryName;
      final isTablet = MediaQuery.of(context).size.width > 600;

      return Row(children: [
        SizedBox(
          width: isTablet ? 280 : 220,
          child: CategorySidebar(
            categories: filteredCats,
            selectedId: _selectedCatId,
            searchController: _catSearchCtrl,
            searchHint: 'Search Categories',
            onSearch: (v) => setState(() => _catSearch = v),
            onSelect: (id) => setState(() => _selectedCatId = id),
          ),
        ),
        Expanded(
          child: Column(children: [
            if (widget.searchQuery.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(catName,
                    style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
              ),
            Expanded(
              child: isError
                  ? _RetryWidget(onRetry: prov.loadSeriesContent)
                  : isLoading && series.isEmpty
                      ? _LoadingGrid(isTablet: isTablet)
                      : series.isEmpty
                          ? const _Empty()
                          : GridView.builder(
                              padding: const EdgeInsets.all(8),
                              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: isTablet ? 5 : 3,
                                childAspectRatio: 0.62,
                                crossAxisSpacing: 6,
                                mainAxisSpacing: 6,
                              ),
                              itemCount: series.length,
                              cacheExtent: 1000,
                              itemBuilder: (_, i) => MediaCard(
                                title: series[i].name,
                                imageUrl: series[i].cover,
                                isFavorite: series[i].isFavorite,
                                onTap: () => _openSeries(series[i]),
                                onFav: () => prov.toggleSeriesFav(series[i].seriesId),
                              ),
                            ),
            ),
            if (isLoading && series.isNotEmpty)
              const LinearProgressIndicator(
                  backgroundColor: AppTheme.bgCard,
                  valueColor: AlwaysStoppedAnimation(AppTheme.primary)),
          ]),
        ),
      ]);
    });
  }
}

class _LoadingGrid extends StatelessWidget {
  final bool isTablet;
  const _LoadingGrid({required this.isTablet});
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isTablet ? 5 : 3, childAspectRatio: 0.62, crossAxisSpacing: 6, mainAxisSpacing: 6),
      itemCount: 12,
      itemBuilder: (_, __) => Container(
        decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(10))),
    );
  }
}

class _RetryWidget extends StatelessWidget {
  final VoidCallback onRetry;
  const _RetryWidget({required this.onRetry});
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.error_outline, color: AppTheme.textMuted, size: 48),
      const SizedBox(height: 12),
      const Text('فشل التحميل', style: TextStyle(color: AppTheme.textSecondary)),
      const SizedBox(height: 16),
      ElevatedButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
    ]),
  );
}

class _Empty extends StatelessWidget {
  const _Empty();
  @override
  Widget build(BuildContext context) => const Center(
    child: Text('لا توجد مسلسلات', style: TextStyle(color: AppTheme.textSecondary)));
}
