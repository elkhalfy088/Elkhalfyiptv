import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../models/movie_model.dart';
import '../models/category_model.dart';
import '../utils/app_theme.dart';
import '../widgets/category_sidebar.dart';
import '../widgets/media_card.dart';
import 'vod_player_screen.dart';

class MoviesScreen extends StatefulWidget {
  final String searchQuery;
  const MoviesScreen({super.key, this.searchQuery = ''});
  @override
  State<MoviesScreen> createState() => _MoviesScreenState();
}

class _MoviesScreenState extends State<MoviesScreen> {
  String _selectedCatId = '';
  final _catSearchCtrl = TextEditingController();
  String _catSearch = '';

  @override
  void dispose() {
    _catSearchCtrl.dispose();
    super.dispose();
  }

  void _openMovie(MovieModel movie) {
    final provider = context.read<AppProvider>();
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => VodPlayerScreen(
        title: movie.name,
        streamUrl: provider.getMovieUrl(movie.streamId, movie.containerExtension ?? 'mp4'),
        coverUrl: movie.streamIcon,
        plot: movie.plot,
        genre: movie.genre,
        rating: movie.rating,
        duration: movie.duration,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(builder: (_, prov, __) {
      final isLoading = prov.movieState == LoadingState.loading;
      final isError = prov.movieState == LoadingState.error;
      final categories = prov.movieCategories;
      final filteredCats = _catSearch.isEmpty
          ? categories
          : categories.where((c) => c.categoryName.toLowerCase().contains(_catSearch.toLowerCase())).toList();

      List<MovieModel> movies;
      if (widget.searchQuery.isNotEmpty) {
        movies = prov.searchMovies(widget.searchQuery);
      } else {
        movies = prov.getMoviesByCategory(_selectedCatId);
      }

      final catName = categories
          .firstWhere((c) => c.categoryId == _selectedCatId,
              orElse: () => CategoryModel(categoryId: '', categoryName: 'All'))
          .categoryName;
      final isTablet = MediaQuery.of(context).size.width > 600;

      return Row(children: [
        SizedBox(
          width: isTablet ? 280 : 220,
          child: CategorySidebar(
            categories: filteredCats,
            selectedId: _selectedCatId,
            searchController: _catSearchCtrl,
            searchHint: 'Search Categories',
            onSearch: (v) => setState(() => _catSearch = v),
            onSelect: (id) => setState(() => _selectedCatId = id),
          ),
        ),
        Expanded(
          child: Column(children: [
            if (widget.searchQuery.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(catName,
                    style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
              ),
            Expanded(
              child: isError
                  ? _RetryWidget(onRetry: prov.loadMovieContent)
                  : isLoading && movies.isEmpty
                      ? _LoadingMovieGrid(isTablet: isTablet)
                      : movies.isEmpty
                          ? const _Empty(msg: 'لا توجد أفلام')
                          : GridView.builder(
                              padding: const EdgeInsets.all(8),
                              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: isTablet ? 5 : 3,
                                childAspectRatio: 0.62,
                                crossAxisSpacing: 6,
                                mainAxisSpacing: 6,
                              ),
                              itemCount: movies.length,
                              cacheExtent: 1000,
                              itemBuilder: (_, i) => MediaCard(
                                title: movies[i].name,
                                imageUrl: movies[i].streamIcon,
                                isFavorite: movies[i].isFavorite,
                                onTap: () => _openMovie(movies[i]),
                                onFav: () => prov.toggleMovieFav(movies[i].streamId),
                              ),
                            ),
            ),
            if (isLoading && movies.isNotEmpty)
              const LinearProgressIndicator(
                  backgroundColor: AppTheme.bgCard,
                  valueColor: AlwaysStoppedAnimation(AppTheme.primary)),
          ]),
        ),
      ]);
    });
  }
}

class _LoadingMovieGrid extends StatelessWidget {
  final bool isTablet;
  const _LoadingMovieGrid({required this.isTablet});
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isTablet ? 5 : 3,
        childAspectRatio: 0.62,
        crossAxisSpacing: 6,
        mainAxisSpacing: 6,
      ),
      itemCount: 12,
      itemBuilder: (_, __) => Container(
        decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

class _RetryWidget extends StatelessWidget {
  final VoidCallback onRetry;
  const _RetryWidget({required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.error_outline, color: AppTheme.textMuted, size: 48),
        const SizedBox(height: 12),
        const Text('فشل التحميل', style: TextStyle(color: AppTheme.textSecondary)),
        const SizedBox(height: 16),
        ElevatedButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
      ]),
    );
  }
}

class _Empty extends StatelessWidget {
  final String msg;
  const _Empty({required this.msg});
  @override
  Widget build(BuildContext context) => Center(
        child: Text(msg, style: const TextStyle(color: AppTheme.textSecondary)));
}
